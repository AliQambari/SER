# NeuroRecall
## Heroku Deploy here : 
https://neurorecall.herokuapp.com/

"Under DEV. by AQ"

# Files and Folders:

📂 app.py: main app written in python 

📂 templates: HTML files used by Flask "render_template" CMD

📂 static: containing JS files for recorder used in the app and CSS files

📂 upload: test audio file

📂 procfile: a file containing required CMDs for deploying the app on Heruko

📂 requirements.txt: all libraries needed to run the app

📂 mypickles.pickle: pickle file used as a temporary data container

![LANDING PAGE](https://github.com/AliQambari/neurorecall/blob/main/upload/Capture.PNG?raw=true)







