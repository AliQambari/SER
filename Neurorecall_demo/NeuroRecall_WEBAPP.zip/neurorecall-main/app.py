from email.policy import default
from encodings import utf_8
import speech_recognition as sr
from flask import logging, Flask, render_template, request, flash, send_file
import pickle
all_words =['پرده','گوریل','فلفل','میز','اتوبوس','ببر'
            ,'یخچال','دوچرخه','سیر','موکت','هویج','تراکتور','پارو','سوسمار','سیب','قناری']

app = Flask(__name__)
app.secret_key = "aqaqaqaq"

@app.route('/')
def index():
    
    empty_list = []
    with open('mypickle.pickle', 'wb') as f:
        pickle.dump(empty_list, f)
        f.close() 
    return render_template('index.html')
      
@app.route('/audio_to_text/')
def audio_to_text():
  
    flash("پس ازگوش کردن به فایل صوتی ابتدا با فشردن دکمه شروع کلمات را بازگو کنید و سپس در انتها روی توقف کلیک کنید")
    return render_template('audio_to_text.html')

@app.route('/audio', methods=['POST'])

def audio():       
    r = sr.Recognizer()
    with open('upload/audio.wav', 'wb') as f:
        f.write(request.data)
    with sr.AudioFile('upload/audio.wav') as source:
        audio_data = r.record(source)
        text = r.recognize_google(audio_data, language='fa', show_all=True)
        with open('mypickle.pickle', 'wb') as f:
              pickle.dump(text, f)
        print(text)
        return_text = "کلمات پیدا شده : <br> "
        try:
            for num, texts in enumerate(text['alternative']):
                return_text += str(num+1) +") " + texts['transcript']  + " <br> "
        except:
            return_text = "چیزی یافت نشد! "
   
    return str(return_text)
       
       
@app.route('/result/')
def result():
    sp = open('mypickle.pickle','rb')
    spoken_words = pickle.load(sp)
    spoken_words = [spoken_words]
    z = []
    for i in range(len(spoken_words)):
          z.append(spoken_words[i])

    if (z[0]) == []:
        return  render_template('result.html',data = "Didn't catch you! \n Please speak a bit louder." )
             
    elif (len(z[0]['alternative'])) > 1 :
                        
                f = z[0]['alternative']
                ff = []
                for iii in range (len(f)):
                     ff.append((f[iii]['transcript']))
                ff = ' '.join(ff)
                WhatUserSaid = ff.split()
                res = []
                for iiii in WhatUserSaid:
                      if iiii not in res:
                          res.append(iiii) 

                final = []
                for iiiii in all_words:
                     if iiiii in res:
                           final.append(iiiii) 
                out2 = (str(len(final))+" word(s) out of "+str(len(all_words))+" was(were) correctly recalled.")
                out = [out2, final]
    else:    
                f = z[0]['alternative']
                ff = []
                for iii in range (len(f)):
                     ff.append((f[0]['transcript']))
                ff = ' '.join(ff)
                WhatUserSaid = ff.split()
                res = []
                for iiii in WhatUserSaid:
                     if iiii not in res:
                            res.append(iiii) 

                final = []
                for iiiii in all_words:
                     if iiiii in res:
                          final.append(iiiii) 
                out2 = (str(len(final))+" word(s) out of "+str(len(all_words))+" was(were) correctly recalled.") 
                out = [out2, final]
            
              
    return  render_template('result.html',data = out )
                     
if __name__ == "__main__":
    app.run(debug=True)
    app.config.update(SESSION_COOKIE_SAMESITE="None", SESSION_COOKIE_SECURE=True)
